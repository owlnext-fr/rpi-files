'use client';
import { CheckResult } from '../hooks/useApiCheck'
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react'

interface ServiceStatusItemProps {
  service: CheckResult
}

export function ServiceStatusItem({ service }: ServiceStatusItemProps) {
  const getStatusColor = (status: CheckResult['status']) => {
    switch (status) {
      case 'operational':
        return 'text-green-400'
      case 'degraded':
        return 'text-yellow-400'
      case 'outage':
        return 'text-red-400'
      default:
        return 'text-gray-400'
    }
  }

  const getStatusIcon = (status: CheckResult['status']) => {
    switch (status) {
      case 'operational':
        return <CheckCircle className="w-6 h-6" />
      case 'degraded':
        return <AlertTriangle className="w-6 h-6" />
      case 'outage':
        return <XCircle className="w-6 h-6" />
      default:
        return null
    }
  }

  return (
    <div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg shadow">
      <div className="flex items-center space-x-4">
        <div className={`${getStatusColor(service.status)}`}>
          {getStatusIcon(service.status)}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">{service.name}</h3>
          {service.value && (
            <p className="text-sm text-gray-400">
              Valeur : {typeof service.value === 'string' ? service.value.substring(0, 50) : service.value}
            </p>
          )}
        </div>
      </div>
      <div className={`font-semibold ${getStatusColor(service.status)}`}>
        {service.status === 'operational' ? 'Opérationnel' : 
         service.status === 'degraded' ? 'Dégradé' : 'Panne'}
      </div>
    </div>
  )
}

