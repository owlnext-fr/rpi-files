"use client";
import { AlertOctagon } from "lucide-react";
import { CheckResult } from "../hooks/useApiCheck";
import React from "react";

interface IssueCounterProps {
  data: CheckResult;
}

export function IssueCounter({ data }: IssueCounterProps) {
  return (
    <div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg shadow">
      <div className="flex items-center space-x-4">
        <AlertOctagon className="w-6 h-6 text-orange-400" />
        <div>
          <h3 className="text-lg font-semibold text-white">
            Issues non résolues
          </h3>
          <p className="text-sm text-gray-400">
            Nombre total d&apos;erreurs distinctes
          </p>
        </div>
      </div>
      <div className="text-2xl font-bold text-orange-400">
        {data.value ?? "N/A"}
      </div>
    </div>
  );
}
