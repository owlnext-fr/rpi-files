"use client";

import { useEffect, useState, useCallback } from "react";
import { ServiceStatusItem } from "./ServiceStatusItem";
import { IssueCounter } from "./IssueCounter";
import { ErrorDisplay } from "./ErrorDisplay";
import { Loader } from "./Loader";
import { Checkpoint, useApiCheck } from "../hooks/useApiCheck";
import { useAppRotation } from "../hooks/useAppRotation";
import { useAudioAlert } from "../hooks/useAudioAlert";
import { Config, useConfig } from "../hooks/useConfig";
import { RefreshCw } from "lucide-react";
import React from "react";

export default function StatusPage() {
  const { config, isLoading: configLoading, error: configError } = useConfig();
  const {
    currentApp,
    rotateToApp,
    apps,
    error: rotationError,
  } = useAppRotation();
  const {
    results,
    lastUpdate,
    hasChanges,
    isLoading: checkpointsLoading,
    refreshCheckpoints,
    isFirstLoad,
  } = useApiCheck(
    currentApp as Config["apps"][0] & { checkpoints: Checkpoint[] }
  );
  const { isMuted, toggleMute, muteEndTime, playAlert } =
    useAudioAlert(hasChanges);
  const [key, setKey] = useState(0);
  const [timeUntilNextRotation, setTimeUntilNextRotation] = useState(
    config?.rotationInterval ?? 10000
  );

  const resetRotationTimer = useCallback(() => {
    setTimeUntilNextRotation(config?.rotationInterval ?? 10000);
  }, [config]);

  useEffect(() => {
    setKey((prevKey) => prevKey + 1);
    resetRotationTimer();
  }, [currentApp, resetRotationTimer]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeUntilNextRotation((prevTime) => {
        if (prevTime <= 1000) {
          refreshCheckpoints();
          return config?.rotationInterval ?? 10000;
        }
        return prevTime - 1000;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [config, refreshCheckpoints]);

  useEffect(() => {
    if (isFirstLoad && results.length > 0) {
      const hasErrors = results.some(
        (result) => result.status !== "operational"
      );
      if (hasErrors && !isMuted) {
        playAlert();
      }
    }
  }, [isFirstLoad, results, isMuted, playAlert]);

  const handleRefresh = useCallback(() => {
    refreshCheckpoints();
    resetRotationTimer();
  }, [refreshCheckpoints, resetRotationTimer]);

  if (configLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
        Chargement de la configuration...
      </div>
    );
  }

  if (configError) {
    return (
      <ErrorDisplay
        message={
          configError ||
          "Une erreur s'est produite lors du chargement de la configuration."
        }
      />
    );
  }

  if (!config) {
    return <ErrorDisplay message="La configuration n'a pas pu être chargée." />;
  }

  if (rotationError) {
    return <ErrorDisplay message={rotationError} />;
  }

  if (!currentApp) {
    return (
      <ErrorDisplay message="Aucune application disponible dans la configuration." />
    );
  }

  const services = results.filter(
    (result) => result.name !== "Compteur d'issues"
  );
  const issueCounter = results.find(
    (result) => result.name === "Compteur d'issues"
  );

  return (
    <div
      key={key}
      className="min-h-screen flex flex-col bg-gray-900 text-white"
    >
      <main className="flex-grow p-8 pb-16">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">{currentApp.name}</h1>
            <div className="flex space-x-2">
              {apps.length > 1 &&
                apps.map((app, index) => (
                  <button
                    key={app.name}
                    onClick={() => {
                      rotateToApp(index);
                      resetRotationTimer();
                    }}
                    className={`px-3 py-1 rounded ${
                      currentApp.name === app.name
                        ? "bg-blue-600 text-white"
                        : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                    }`}
                  >
                    {app.name}
                  </button>
                ))}
              <button
                onClick={handleRefresh}
                disabled={checkpointsLoading}
                className="px-3 py-1 rounded bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>
          <h2 className="text-xl mb-8 text-center text-gray-400">
            État des Services
          </h2>
          {checkpointsLoading && <Loader />}
          {issueCounter && (
            <div className="mb-8">
              <IssueCounter data={issueCounter} />
            </div>
          )}
          <div className="grid gap-6 md:grid-cols-2">
            {services.map((service) => (
              <ServiceStatusItem key={service.name} service={service} />
            ))}
          </div>
        </div>
      </main>
      <footer className="bg-gray-800 border-t border-gray-700 p-4 sticky bottom-0 left-0 right-0">
        <div className="max-w-4xl mx-auto text-center text-sm text-gray-400">
          <p>
            Dernière mise à jour :{" "}
            {lastUpdate ? lastUpdate.toLocaleString() : "N/A"}
          </p>
          <p>
            Prochaine mise à jour : dans{" "}
            {Math.ceil(timeUntilNextRotation / 1000)} secondes
          </p>
          <button
            onClick={toggleMute}
            className={`mt-2 px-4 py-2 rounded ${
              isMuted
                ? "bg-red-600 text-gray-100"
                : "bg-gray-700 text-gray-200 hover:bg-gray-600"
            }`}
          >
            {isMuted
              ? `Son coupé (${Math.ceil((muteEndTime! - Date.now()) / 1000)}s)`
              : "Couper le son"}
          </button>
        </div>
      </footer>
    </div>
  );
}
