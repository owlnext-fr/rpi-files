'use client';
import { XCircle } from 'lucide-react'

interface ErrorDisplayProps {
  message: string
}

export function ErrorDisplay({ message }: ErrorDisplayProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="bg-red-600 text-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <div className="flex items-center mb-4">
          <XCircle className="w-8 h-8 mr-2" />
          <h1 className="text-2xl font-bold">Erreur</h1>
        </div>
        <p className="text-lg">{message}</p>
      </div>
    </div>
  )
}

