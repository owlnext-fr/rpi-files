import { Loader2 } from 'lucide-react'

export function Loader() {
  return (
    <div className="flex items-center justify-center p-4">
      <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
      <span className="ml-2 text-sm text-gray-500">Rafraîchissement en cours...</span>
    </div>
  )
}

