/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState, useEffect, useCallback } from "react";
import jsonpath from "jsonpath";
import { Config, useConfig } from "./useConfig";

type CheckpointType =
  | "presence"
  | "issue_counter"
  | "json_validator"
  | "text_validator";

interface BaseCheckpoint {
  name: string;
  type: CheckpointType;
  endpoint: string;
  method: string;
  headers: Record<string, string>;
  body?: Record<string, any>;
}

interface PresenceCheckpoint extends BaseCheckpoint {
  type: "presence";
}

interface IssueCounterCheckpoint extends BaseCheckpoint {
  type: "issue_counter";
}

interface JsonValidatorCheckpoint extends BaseCheckpoint {
  type: "json_validator";
  expectedValue: any;
  jsonPath: string;
}

interface TextValidatorCheckpoint extends BaseCheckpoint {
  type: "text_validator";
  expectedText: string;
}

export type Checkpoint =
  | PresenceCheckpoint
  | IssueCounterCheckpoint
  | JsonValidatorCheckpoint
  | TextValidatorCheckpoint;

export type Status = "operational" | "degraded" | "outage";

export interface CheckResult {
  name: string;
  status: Status;
  lastUpdated: Date;
  value?: number | string;
  rawData?: any; // Pour stocker les données brutes de Glitchtip si nécessaire
}

async function checkEndpoint(checkpoint: Checkpoint): Promise<CheckResult> {
  try {
    const response = await fetch(checkpoint.endpoint, {
      method: checkpoint.method,
      headers: checkpoint.headers,
      body: checkpoint.body ? JSON.stringify(checkpoint.body) : undefined,
    });

    if (checkpoint.type === "presence") {
      return {
        name: checkpoint.name,
        status: response.ok ? "operational" : "outage",
        lastUpdated: new Date(),
      };
    }

    if (!response.ok) {
      throw new Error("API request failed");
    }

    const data = await response.json();

    switch (checkpoint.type) {
      case "issue_counter":
        const issues = Array.isArray(data) ? data : [data];
        const openIssuesCount = issues.reduce((total, issue) => {
          return (
            total +
            (issue.status === "unresolved" ? parseInt(issue.count, 10) : 0)
          );
        }, 0);
        return {
          name: checkpoint.name,
          status: "operational",
          lastUpdated: new Date(),
          value: openIssuesCount,
        };
      case "json_validator":
        const jsonValue = jsonpath.query(data, checkpoint.jsonPath)[0];
        const status =
          jsonValue === checkpoint.expectedValue ? "operational" : "outage";
        return {
          name: checkpoint.name,
          status,
          lastUpdated: new Date(),
          value: jsonValue,
        };
      case "text_validator":
        const textContent = await response.text();
        const textStatus = textContent.includes(checkpoint.expectedText)
          ? "operational"
          : "outage";
        return {
          name: checkpoint.name,
          status: textStatus,
          lastUpdated: new Date(),
          value: textContent,
        };
      default:
        throw new Error("Unknown checkpoint type");
    }
  } catch (error) {
    console.error(`Error checking ${checkpoint.name}:`, error);
    return {
      name: checkpoint.name,
      status: "outage",
      lastUpdated: new Date(),
    };
  }
}

export function useApiCheck(
  currentApp: (Config["apps"][0] & { checkpoints: Checkpoint[] }) | null
): {
  results: CheckResult[];
  lastUpdate: Date | null;
  hasChanges: boolean;
  isLoading: boolean;
  refreshCheckpoints: () => Promise<void>;
  isFirstLoad: boolean;
} {
  const { config } = useConfig();
  const [results, setResults] = useState<CheckResult[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFirstLoad, setIsFirstLoad] = useState(true);

  const checkAll = useCallback(async () => {
    if (!currentApp || !config) return;

    setIsLoading(true);
    try {
      const newResults = await Promise.all(
        currentApp.checkpoints.map(checkEndpoint)
      );
      setResults((prevResults) => {
        const changes = newResults.some((result, index) => {
          const prevResult = prevResults[index];
          return (
            prevResult &&
            (prevResult.status !== result.status ||
              prevResult.value !== result.value)
          );
        });
        setHasChanges(changes);
        return newResults;
      });
      setLastUpdate(new Date());
      if (isFirstLoad) {
        setIsFirstLoad(false);
      }
    } catch (error) {
      console.error("Error checking endpoints:", error);
    } finally {
      setIsLoading(false);
    }
  }, [currentApp, config, isFirstLoad]);

  useEffect(() => {
    checkAll();
    const interval = setInterval(checkAll, config?.rotationInterval || 60000);

    return () => clearInterval(interval);
  }, [checkAll, config]);

  return {
    results,
    lastUpdate,
    hasChanges,
    isLoading,
    refreshCheckpoints: checkAll,
    isFirstLoad,
  };
}
