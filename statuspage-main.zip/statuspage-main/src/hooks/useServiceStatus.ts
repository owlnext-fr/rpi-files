/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect } from "react";
import { useConfig } from "./useConfig";

type Status = "operational" | "degraded" | "outage";

export interface ServiceStatus {
  name: string;
  status: Status;
  lastUpdated: Date;
}

export function useServiceStatus() {
  const { config } = useConfig();

  const [services, setServices] = useState<ServiceStatus[]>(
    () =>
      config?.apps.map((service) => ({
        name: service.name,
        status: "operational",
        lastUpdated: new Date(),
      })) || []
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setServices((prevServices) =>
        prevServices.map((service) => ({
          ...service,
          status:
            Math.random() > 0.8
              ? "degraded"
              : Math.random() > 0.95
              ? "outage"
              : "operational",
          lastUpdated: new Date(),
        }))
      );
    }, config?.rotationInterval || 10000);

    return () => clearInterval(interval);
  }, [config?.rotationInterval]);

  return services;
}
