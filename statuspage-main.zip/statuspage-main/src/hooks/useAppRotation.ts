import { useState, useEffect, useCallback, useRef } from 'react'
import { useConfig } from './useConfig'

export function useAppRotation() {
  const { config } = useConfig()
  const [currentAppIndex, setCurrentAppIndex] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const rotationTimerRef = useRef<NodeJS.Timeout | null>(null)

  const startRotationTimer = useCallback(() => {
    if (rotationTimerRef.current) {
      clearInterval(rotationTimerRef.current)
    }
    if (!config || !config.apps || config.apps.length === 0) {
      setError("Aucune application trouvée dans la configuration.")
      return
    }
    rotationTimerRef.current = setInterval(() => {
      setCurrentAppIndex((prevIndex) => (prevIndex + 1) % config.apps.length)
    }, config.rotationInterval)
  }, [config])

  const rotateToApp = useCallback((index: number) => {
    if (!config || !config.apps) {
      setError("Configuration non chargée.")
      return
    }
    if (index < 0 || index >= config.apps.length) {
      setError(`Index d'application invalide: ${index}`)
      return
    }
    setCurrentAppIndex(index)
    startRotationTimer()
  }, [config, startRotationTimer])

  useEffect(() => {
    if (!config) {
      return
    }
    if (!config.apps || config.apps.length === 0) {
      setError("Aucune application trouvée dans la configuration.")
      return
    }
    startRotationTimer()
    return () => {
      if (rotationTimerRef.current) {
        clearInterval(rotationTimerRef.current)
      }
    }
  }, [config, startRotationTimer])

  return {
    currentApp: config?.apps && config.apps.length > 0 ? config.apps[currentAppIndex] : null,
    rotateToApp,
    apps: config?.apps || [],
    error
  }
}

