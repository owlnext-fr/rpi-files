"use client";

import { useState, useEffect, useCallback } from "react";
import { useConfig } from "./useConfig";

export function useAudioAlert(shouldPlay: boolean) {
  const { config } = useConfig();
  const [isMuted, setIsMuted] = useState(false);
  const [muteEndTime, setMuteEndTime] = useState<number | null>(null);

  const playAlert = useCallback(() => {
    if (!isMuted) {
      const audio = new Audio("/alert.mp3");
      audio.play();
    }
  }, [isMuted]);

  useEffect(() => {
    if (shouldPlay) {
      playAlert();
    }
  }, [shouldPlay, playAlert]);

  useEffect(() => {
    if (muteEndTime) {
      const timer = setTimeout(() => {
        setIsMuted(false);
        setMuteEndTime(null);
      }, muteEndTime - Date.now());

      return () => clearTimeout(timer);
    }
  }, [muteEndTime]);

  const toggleMute = useCallback(() => {
    if (isMuted) {
      setIsMuted(false);
      setMuteEndTime(null);
    } else {
      setIsMuted(true);
      setMuteEndTime(Date.now() + (config?.muteDuration || 300000));
    }
  }, [isMuted, config]);

  return { isMuted, toggleMute, muteEndTime, playAlert };
}
