/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState, useEffect } from "react";

export interface Config {
  apps: {
    name: string;
    checkpoints: {
      name: string;
      type: string;
      endpoint: string;
      method: string;
      headers: Record<string, string>;
      body?: Record<string, any>;
      expectedValue?: any;
      jsonPath?: string;
      expectedText?: string;
    }[];
  }[];
  rotationInterval: number;
  muteDuration: number;
}

export function useConfig() {
  const [config, setConfig] = useState<Config | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchConfig() {
      try {
        const response = await fetch("/config.json");
        if (!response.ok) {
          throw new Error("Failed to fetch configuration");
        }
        const text = await response.text();
        try {
          const data = JSON.parse(text);
          setConfig(data);
        } catch (parseError) {
          throw new Error(
            "Failed to parse configuration: " +
              (parseError instanceof Error
                ? parseError.message
                : String(parseError))
          );
        }
      } catch (err) {
        setError(
          "Error loading configuration: " +
            (err instanceof Error ? err.message : String(err))
        );
      } finally {
        setIsLoading(false);
      }
    }

    fetchConfig();
  }, []);

  return { config, isLoading, error };
}
