import React from "react";
import StatusPage from "../components/status-page";
import "../styles/main.css";

export default function Home() {
  return <StatusPage />;
}
