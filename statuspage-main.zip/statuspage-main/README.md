# Owlnext - statuspage

This is a repository hosting statuspage for Owlnext TV screens.

## Prerequisite

### Development

- nvm
- npm latest

### Deployment

- caddy

## Use

1. git clone this repository.
2. `cd` into the repository.
3. `cd` into the `dist` directory.
4. Create a `config.json` file using `cp ../config.example.json config.json`.
5. Edit the `config.json` file to match your needs.
6. Run `caddy run`.

You can access the statuspage at `http://localhost:8080`.

## Development

1. `cd` into the repository.
2. Run `nvm use`.
3. Run `npm install`.
4. Run `npm run dev`.

## Build

1. `cd` into the repository.
2. Run `nvm use`.
3. Run `npm install`.
4. Run `npm run build`.

Then commit + push the changes.
